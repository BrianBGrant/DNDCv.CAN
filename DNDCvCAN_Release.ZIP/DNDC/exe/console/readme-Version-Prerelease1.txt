Version built Nov 16, 2022
Includes SM operational fixes for CONSOLE application for output
example "start /wait dndc95.exe -output [yourpathname to output directory] -s [batch txt file you want to run]"
"start /wait dndc95.exe -output D:\outputDNDC -s D:\DNDC\TONY\BatchDND\Barley_all.txt"

#Bug fixes
Spelling mistake #define CONSOLE
Misc File I/O call (overload of file handlers)


