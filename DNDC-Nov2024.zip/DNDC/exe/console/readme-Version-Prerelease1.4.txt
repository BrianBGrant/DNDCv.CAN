Version built March 26,2024
Includes SM operational fixes for CONSOLE application for output
example "start /wait dndc95.exe -output [yourpathname to output results directory] -s [batch txt file you want to run: Should be in the same directory as exe] -daily [0 (no daily files) or 1 {for daily output generation)] -root [where your root DNDC95 directory is located]"
"start /wait dndc95.exe -root D:\DNDC -output D:\outputDNDC -s D:\DNDC\TONY\BatchDND\Barley_all.txt -daily 0"





#Bug fixes
Spelling mistake #define CONSOLE
Misc File I/O call (overload of file handlers)


