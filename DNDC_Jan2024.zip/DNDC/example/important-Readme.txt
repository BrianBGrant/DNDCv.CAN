The files in this directory are intended to run DNDC off the D: hard drive.
If you want to run DNDC on a different drive you need to change the following files
exampleRun.dnd (find replace  all D: to C:) in the file. This should point to the correct locations for your weather files and exampleSoil file.